function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

/**
 * @copyright 2021 Tridium, Inc. All Rights Reserved.
 */

/**
 * API Status: **Private**
 * @module nmodule/niagaraDriver/rc/wb/mgr/commands/NiagaraPointMatchCommand
 */
define(['Promise', 'nmodule/webEditors/rc/wb/mgr/mgrUtils', 'nmodule/webEditors/rc/wb/mgr/commands/MatchCommand'], function (Promise, mgrUtils, MatchCommand) {
  'use strict';

  var getMainTableSelection = mgrUtils.getMainTableSelectedSubjects;
  var getLearnTableSelection = mgrUtils.getLearnTableSelectedSubjects;
  /**
   * A match command for NiagaraPointUxManager
   *
   * @class
   * @extends nmodule/webEditors/rc/wb/mgr/commands/MatchCommand
   * @alias module:nmodule/niagaraDriver/rc/wb/mgr/commands/NiagaraPointMatchCommand
   */

  return /*#__PURE__*/function (_MatchCommand) {
    _inherits(NiagaraPointUxManager, _MatchCommand);

    var _super = _createSuper(NiagaraPointUxManager);

    function NiagaraPointUxManager() {
      _classCallCheck(this, NiagaraPointUxManager);

      return _super.apply(this, arguments);
    }

    _createClass(NiagaraPointUxManager, [{
      key: "tableSelectionChanged",
      value: function tableSelectionChanged() {
        var _this = this;

        var enabled = false;
        var mgr = this.$mgr;
        var learnTableSelection = getLearnTableSelection(mgr);
        var mainTableSelection = getMainTableSelection(mgr);

        if (mainTableSelection.length === 1 && learnTableSelection.length === 1) {
          var learnSel = learnTableSelection[0];
          var mainSel = mainTableSelection[0];
          var mainType = mainSel.getType().getTypeSpec();
          return mgr.getTypesForDiscoverySubject(learnSel).then(function (typeInfos) {
            for (var i = 0; i < typeInfos.length; i++) {
              var typeSpec = typeInfos[i].getType().getTypeSpec();

              if (typeSpec === mainType) {
                enabled = true;
                break;
              }
            }

            return _this.setEnabled(enabled);
          });
        }

        return this.setEnabled(enabled);
      }
    }]);

    return NiagaraPointUxManager;
  }(MatchCommand);
});
