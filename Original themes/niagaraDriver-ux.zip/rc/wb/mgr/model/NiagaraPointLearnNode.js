function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

/**
 * @copyright 2021 Tridium, Inc. All Rights Reserved.
 * @author Vikram Nagulan
 */

/**
 * API Status: **Private**
 * @module nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointLearnNode
 */
define(['baja!', 'Promise', 'nmodule/webEditors/rc/fe/baja/util/compUtils', 'nmodule/webEditors/rc/wb/tree/TreeNode'], function (baja, Promise, compUtils, TreeNode) {
  'use strict';

  var getDisplayName = compUtils.getDisplayName;

  function getName(value) {
    if (!baja.hasType(value, 'baja:Complex')) {
      return '';
    }

    var name = value.getName();

    if (!name && baja.hasType(value, 'baja:Station')) {
      var ord = value.getNavOrd();

      if (ord) {
        name = ord.relativizeToSession();
      }
    } //use this for when loading an unmounted component in


    return String(name || value.getType().getTypeName());
  }
  /**
   * A special TreeNode representing discovered Niagara Points
   *
   * @class
   * @alias module:nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointLearnNode
   * @extends module:nmodule/webEditors/rc/wb/tree/TreeNode
   */


  return /*#__PURE__*/function (_TreeNode) {
    _inherits(NiagaraPointLearnNode, _TreeNode);

    var _super = _createSuper(NiagaraPointLearnNode);

    function NiagaraPointLearnNode(value, niagaraPointDeviceExt, name, displayName) {
      var _this;

      _classCallCheck(this, NiagaraPointLearnNode);

      var nodeName = name || getName(value),
          nodeDisplayName = displayName || getDisplayName(value);
      _this = _super.call(this, nodeName, nodeDisplayName);
      _this.$value = value;
      _this.$parent = null;
      _this.$niagaraPointDeviceExt = niagaraPointDeviceExt;
      return _this;
    }

    _createClass(NiagaraPointLearnNode, [{
      key: "getIcon",
      value: function getIcon() {
        if (this.$isKid()) {
          return this.$value.getIcon();
        }

        return baja.Icon.make(this.$value.get(baja.SlotPath.escape('icon.encodeToString')));
      }
    }, {
      key: "value",
      value: function value() {
        return this.$value;
      }
    }, {
      key: "getFullPath",
      value: function getFullPath() {
        var path;
        var parent = this.getParent();

        if (parent) {
          path = parent.getFullPath(); // If this is a child node add only the name because full path upto this node
          // comes from parent's toPathString value

          path.push('/' + this.getName());
        } else {
          path = ['station:|slot:']; // Add base station slot path to the root

          path.push(this.value().get('toPathString'));
        }

        return path;
      }
      /**
       * @private
       * @returns {boolean} 
       */

    }, {
      key: "$isKid",
      value: function $isKid() {
        return !!this.getParent();
      }
      /**
       * @private
       * @returns {Promise<Array.<module:nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointLearnNode>>}
       */

    }, {
      key: "$loadKids",
      value: function $loadKids() {
        var root = 'slot:' + this.$value.get('toPathString'),
            niagaraPointDeviceExt = this.$niagaraPointDeviceExt;
        return Promise.all([niagaraPointDeviceExt.rpc('loadNodes', root), this.$loadParentType(this.$value.get('type'))]).then(function (_ref) {
          var _ref2 = _slicedToArray(_ref, 2),
              result = _ref2[0],
              parentType = _ref2[1];

          var slots = JSON.parse(result);
          return Object.keys(slots).filter(function (key) {
            return key.includes(root) && key !== root;
          }).map(function (key) {
            var s = slots[key].s,
                ordQueryList = baja.Ord.make(s.o).parse(),
                kidValue = baja.$('baja:Component', {
              toPathString: ordQueryList.get(ordQueryList.size() - 1).getBody(),
              type: s.ts,
              handle: ''
            });
            var kidNode = new NiagaraPointLearnNode(kidValue, niagaraPointDeviceExt, s.n, s.d);
            kidNode.$parentType = parentType;
            return kidNode;
          });
        });
      }
      /**
       * 
       * @param {String} parentTypeSpec the parent's type spec
       * @return {Promise.<baja.Type|null>}
       */

    }, {
      key: "$loadParentType",
      value: function $loadParentType(parentTypeSpec) {
        return baja.importTypes([parentTypeSpec]).then(function (_ref3) {
          var _ref4 = _slicedToArray(_ref3, 1),
              type = _ref4[0];

          return type;
        })["catch"](function () {
          return null;
        });
      }
    }]);

    return NiagaraPointLearnNode;
  }(TreeNode);
});
