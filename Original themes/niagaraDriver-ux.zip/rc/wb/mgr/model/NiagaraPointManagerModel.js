function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/**
 * @copyright 2021 Tridium, Inc. All Rights Reserved.
 * @author Vikram Nagulan
 */

/**
 * API Status: **Private**
 * @module nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointManagerModel
 */
define(['baja!', 'baja!niagaraDriver:NiagaraProxyExt,control:ControlPoint', 'lex!driver', 'underscore', 'Promise', 'nmodule/driver/rc/wb/mgr/PointMgrModel', 'nmodule/webEditors/rc/fe/baja/util/typeUtils', 'nmodule/webEditors/rc/wb/mgr/MgrTypeInfo', 'nmodule/webEditors/rc/wb/mgr/model/columns/DisplayNameMgrColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/NameMgrColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/PathMgrColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/PropertyMgrColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/PropertyPathMgrColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/IconMgrColumn', 'nmodule/webEditors/rc/wb/table/model/columns/ToStringColumn', 'nmodule/webEditors/rc/wb/mgr/model/columns/TypeMgrColumn', 'nmodule/webEditors/rc/wb/table/model/Column'], function (baja, types, lexs, _, Promise, PointMgrModel, typeUtils, MgrTypeInfo, DisplayNameMgrColumn, NameMgrColumn, PathMgrColumn, PropertyMgrColumn, PropertyPathMgrColumn, IconMgrColumn, ToStringColumn, TypeMgrColumn, Column) {
  'use strict';

  var _Column$flags = Column.flags,
      UNSEEN = _Column$flags.UNSEEN,
      READONLY = _Column$flags.READONLY,
      EDITABLE = _Column$flags.EDITABLE;
  var CONTROL_POINT_TYPE = baja.lt('control:ControlPoint'),
      NIAGARA_PROXY_EXT_TYPE = baja.lt('niagaraDriver:NiagaraProxyExt');

  var _lexs = _slicedToArray(lexs, 1),
      driverLex = _lexs[0];
  /**
   * MgrColumn for the coversion type
   * 
   * @inner
   * @class
   * @extends module:nmodule/webEditors/rc/wb/mgr/model/columns/PropertyPathMgrColumn
   */


  var ConversionColumn = /*#__PURE__*/function (_PropertyPathMgrColum) {
    _inherits(ConversionColumn, _PropertyPathMgrColum);

    var _super = _createSuper(ConversionColumn);

    function ConversionColumn() {
      _classCallCheck(this, ConversionColumn);

      return _super.apply(this, arguments);
    }

    _createClass(ConversionColumn, [{
      key: "buildCell",
      value: function buildCell(row, dom) {
        var conversion = this.getProposedValueFor(row);
        return typeUtils.getTypeDisplayName(conversion.getType()).then(function (name) {
          dom.text(name);
        });
      }
    }]);

    return ConversionColumn;
  }(PropertyPathMgrColumn);

  function getNewTypes() {
    var types = [];
    PointMgrModel.addBooleanPointTypes(false, types);
    PointMgrModel.addNumericPointTypes(false, types);
    PointMgrModel.addEnumPointTypes(false, types);
    PointMgrModel.addStringPointTypes(false, types);
    return MgrTypeInfo.make(types);
  }

  function makeColumns() {
    return [new IconMgrColumn(), new PathMgrColumn({
      flags: UNSEEN | READONLY
    }), new NameMgrColumn({
      flags: EDITABLE
    }), new DisplayNameMgrColumn({
      flags: UNSEEN | EDITABLE
    }), new TypeMgrColumn({
      flags: EDITABLE | UNSEEN
    }), new PropertyPathMgrColumn('proxyExt/pointId', {
      displayName: driverLex.get('pointId'),
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: EDITABLE
    }), new ToStringColumn('out', {
      displayName: driverLex.get('out')
    }), new PropertyPathMgrColumn('proxyExt/enabled', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: EDITABLE | UNSEEN
    }), new PropertyMgrColumn('facets', {
      type: CONTROL_POINT_TYPE,
      flags: EDITABLE | UNSEEN
    }), new PropertyPathMgrColumn('proxyExt/tuningPolicyName', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: EDITABLE | UNSEEN
    }), new PropertyPathMgrColumn('proxyExt/subscriptionStatus', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: 0
    }), new PropertyPathMgrColumn('proxyExt/faultCause', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: UNSEEN
    }), new PropertyPathMgrColumn('proxyExt/readValue', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: UNSEEN
    }), new PropertyPathMgrColumn('proxyExt/deviceFacets', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: EDITABLE | UNSEEN
    }), new ConversionColumn('proxyExt/conversion', {
      type: NIAGARA_PROXY_EXT_TYPE,
      flags: EDITABLE | UNSEEN
    }), new PropertyMgrColumn('displayNames', {
      displayName: driverLex.get('displayNames'),
      type: CONTROL_POINT_TYPE,
      flags: READONLY | UNSEEN
    })];
  }
  /**
   * Represents the model backing the Niagara Point Ux Manager view
   * 
   * @class
   * @extends module:nmodule/driver/rc/wb/mgr/PointMgrModel
   * @alias module:nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointManagerModel
   */


  return /*#__PURE__*/function (_PointMgrModel) {
    _inherits(NiagaraPointManagerModel, _PointMgrModel);

    var _super2 = _createSuper(NiagaraPointManagerModel);

    function NiagaraPointManagerModel() {
      _classCallCheck(this, NiagaraPointManagerModel);

      return _super2.apply(this, arguments);
    }

    _createClass(NiagaraPointManagerModel, null, [{
      key: "make",
      value: function make(component) {
        return Promise.all([makeColumns(), getNewTypes()]).then(function (_ref) {
          var _ref2 = _slicedToArray(_ref, 2),
              columns = _ref2[0],
              newTypes = _ref2[1];

          return new NiagaraPointManagerModel({
            component: component,
            columns: columns,
            newTypes: newTypes,
            folderType: 'niagaraDriver:NiagaraPointFolder',
            proxyExtType: 'niagaraDriver:NiagaraProxyExt'
          });
        });
      }
    }]);

    return NiagaraPointManagerModel;
  }(PointMgrModel);
});
