function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _get(target, property, receiver) { if (typeof Reflect !== "undefined" && Reflect.get) { _get = Reflect.get; } else { _get = function _get(target, property, receiver) { var base = _superPropBase(target, property); if (!base) return; var desc = Object.getOwnPropertyDescriptor(base, property); if (desc.get) { return desc.get.call(receiver); } return desc.value; }; } return _get(target, property, receiver || target); }

function _superPropBase(object, property) { while (!Object.prototype.hasOwnProperty.call(object, property)) { object = _getPrototypeOf(object); if (object === null) break; } return object; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/**
 * @copyright 2021 Tridium, Inc. All Rights Reserved.
 * @author Vikram Nagulan
 */

/**
 * API Status: **Private**
 * @module nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointUxManager
 */
define(['baja!', 'baja!control:ControlPoint', 'bajaScript/baja/nav/NavNode', 'Promise', 'lex!workbench', 'log!nmodule.niagaraDriver.rc.wb.mgr.NiagaraPointUxManager', 'nmodule/bql/rc/builder/BqlQueryBuilder', 'nmodule/bql/rc/util/parseBql', 'nmodule/driver/rc/wb/mgr/LearnContextMenuSupport', 'nmodule/driver/rc/wb/mgr/PointMgr', 'nmodule/driver/rc/wb/mgr/PointMgrModel', 'nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointLearn', 'nmodule/niagaraDriver/rc/wb/mgr/commands/NiagaraPointMatchCommand', 'nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointLearnModel', 'nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointManagerModel', 'nmodule/webEditors/rc/fe/baja/util/compUtils', 'nmodule/webEditors/rc/fe/feDialogs', 'nmodule/webEditors/rc/wb/mgr/MgrLearn', 'nmodule/webEditors/rc/wb/mgr/MgrTypeInfo'], function (baja, types, NavNode, Promise, lexs, log, BqlQueryBuilder, parseBql, LearnContextMenuSupport, PointMgr, PointMgrModel, NiagaraPointLearn, NiagaraPointMatchCommand, NiagaraPointLearnModel, NiagaraPointManagerModel, compUtils, feDialogs, MgrLearn, MgrTypeInfo) {
  'use strict';

  var _lexs = _slicedToArray(lexs, 1),
      WB_LEX = _lexs[0];

  var COLUMNS = NiagaraPointLearnModel.COLUMNS;
  var toSelect = parseBql.toSelect;
  var logSevere = log.severe.bind(log);

  var loadSlotInfo = function loadSlotInfo(manager, subject) {
    var pathString = subject.get('toPathString'),
        slotPath = 'slot:' + pathString;
    return manager.$getPointDeviceExt().rpc('loadNodesPartially', [slotPath]).then(function (slots) {
      return slots[slotPath];
    });
  };

  var addNumericPointTypes = PointMgrModel.addNumericPointTypes,
      addBooleanPointTypes = PointMgrModel.addBooleanPointTypes,
      addEnumPointTypes = PointMgrModel.addEnumPointTypes,
      addStringPointTypes = PointMgrModel.addStringPointTypes;
  var FACETS_DEFAULT = baja.Facets.DEFAULT;

  var toNavNode = function toNavNode(obj) {
    return Promise.all((obj.kids || []).map(function (kid) {
      return toNavNode({
        name: kid.n,
        displayName: kid.d,
        ord: kid.o,
        icon: kid.i,
        kids: kid.k
      });
    })).then(function (kids) {
      var navNode = new NavNode({
        navName: obj.name,
        displayName: obj.displayName,
        description: obj.description,
        ord: String(obj.ord),
        icon: obj.icon
      });

      navNode.getNavChildren = function () {
        return Promise.resolve(kids);
      };

      return navNode;
    });
  };

  function isCommand(cmd, displayNameFormat) {
    return cmd.getDisplayNameFormat() === displayNameFormat;
  }

  function getBqlQuery(ordStr) {
    var bqlOrdParts = ordStr.match(/(\|bql:)|(bql:)/gi);
    var pieces = bqlOrdParts ? ordStr.split(bqlOrdParts[0]) : [ordStr];
    return pieces.length > 1 ? pieces[pieces.length - 1] : pieces[0];
  }
  /**
   * A bajaux Point Manager View for NiagaraDriver
   *
   * @class
   * @extends module:nmodule/driver/rc/wb/mgr/PointMgr
   * @alias module:nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointUxManager
   */


  return /*#__PURE__*/function (_PointMgr) {
    _inherits(NiagaraPointUxManager, _PointMgr);

    var _super = _createSuper(NiagaraPointUxManager);

    /**
     * 
     * @param {object} [params] 
     * @param {string} [params.extentTypeSpec] a specific type spec to be used as extent for the 
     *  BQL query. Defaults to control:ControlPoint
     */
    function NiagaraPointUxManager() {
      var _this;

      var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          _ref$extentTypeSpec = _ref.extentTypeSpec,
          extentTypeSpec = _ref$extentTypeSpec === void 0 ? 'control:ControlPoint' : _ref$extentTypeSpec;

      _classCallCheck(this, NiagaraPointUxManager);

      _this = _super.call(this, {
        moduleName: 'niagaraDriver',
        keyName: 'NiagaraPointUxManager',
        folderType: 'niagaraDriver:NiagaraPointFolder',
        subscriptionDepth: 3
      });
      _this.$extentTypeSpec = extentTypeSpec;
      MgrLearn(_assertThisInitialized(_this));
      LearnContextMenuSupport(_assertThisInitialized(_this));
      return _this;
    }

    _createClass(NiagaraPointUxManager, [{
      key: "doInitialize",
      value: function doInitialize(dom) {
        var _this2 = this;

        return _get(_getPrototypeOf(NiagaraPointUxManager.prototype), "doInitialize", this).apply(this, arguments).then(function () {
          dom.on('dblclick', '.discoveryTable tr', function () {
            return _this2.$getAddCommand().invoke();
          });
        });
      }
      /**
       * Make the model backing this manager
       * @param {baja.Component} component 
       * @returns {Promise}
       */

    }, {
      key: "makeModel",
      value: function makeModel(component) {
        return NiagaraPointManagerModel.make(component);
      }
    }, {
      key: "makeLearnModel",
      value: function makeLearnModel() {
        return NiagaraPointLearnModel.make();
      }
      /**
       * @private
       * Replace the standard MatchCommand with the NiagaraPointMatchCommand
       * @returns {Array<module:bajaux/commands/Command>}
       */

    }, {
      key: "makeCommands",
      value: function makeCommands() {
        var _this3 = this;

        var commands = _get(_getPrototypeOf(NiagaraPointUxManager.prototype), "makeCommands", this).apply(this, arguments);

        return commands.map(function (cmd) {
          if (isCommand(cmd, '%lexicon(webEditors:commands.mgr.match.displayName)%')) {
            return new NiagaraPointMatchCommand(_this3);
          }

          return cmd;
        });
      }
      /**
       * 
       * @param {baja.Value} subject 
       * @returns {Promise.<Array.<module:nmodule/webEditors/rc/wb/mgr/MgrTypeInfo>>}
       */

    }, {
      key: "getTypesForDiscoverySubject",
      value: function getTypesForDiscoverySubject(subject) {
        return this.$getInstance(subject).then(function (val) {
          var type = val.getType();
          var types = [];

          if (type.is("baja:IBoolean")) {
            types = addBooleanPointTypes(false, types);
            types = addEnumPointTypes(false, types);
          } else if (type.is("baja:INumeric")) {
            types = addNumericPointTypes(false, types);
          } else if (type.is("baja:IEnum")) {
            types = addEnumPointTypes(false, types);
          }

          addStringPointTypes(false, types);
          return MgrTypeInfo.make(types);
        });
      }
      /**
       * Returns an object with the proposed subject for the manager AddCommand 
       * @param {baja.Component} discovery
       * @param {baja.ControlPoint} point when a match is done, it is the database point that we are matching to
       * @returns {Promise.<Object>}
       */

    }, {
      key: "getProposedValuesFromDiscovery",
      value: function getProposedValuesFromDiscovery(discovery, point) {
        return loadSlotInfo(this, discovery).then(function (slotInfo) {
          if (!slotInfo) {
            return [];
          }

          var s = slotInfo.s;

          var _ref2 = s || {},
              f = _ref2.f;

          return Promise.all([slotInfo, f ? FACETS_DEFAULT.decodeAsync(f) : FACETS_DEFAULT]);
        }).then(function (_ref3) {
          var _ref4 = _slicedToArray(_ref3, 2),
              slotInfo = _ref4[0],
              facets = _ref4[1];

          if (!slotInfo) {
            return {};
          }

          var o = slotInfo.o,
              s = slotInfo.s,
              _ref5 = s || {},
              d = _ref5.d,
              n = _ref5.n;

          return {
            name: point && point.getName() ? point.getName() : n,
            values: {
              pointId: o,
              facets: facets,
              __displayName: d,
              deviceFacets: facets
            }
          };
        });
      }
      /**
       * Returns true if the slot paths match
       * 
       * @param {baja.Component} subject 
       * @param {baja.Value} point 
       * @returns {boolean}
       */

    }, {
      key: "isExisting",
      value: function isExisting(subject, point) {
        if (!baja.hasType(point, 'control:ControlPoint')) {
          return false;
        }

        return point.getProxyExt().getPointId() === 'slot:' + subject.get('toPathString');
      }
      /**
       * Starts a discovery job. Pops open an instance of BqlQueryBuilder
       * editor rooted to the remote config space.
       * 
       * @returns {Promise}
       */

    }, {
      key: "doDiscover",
      value: function doDiscover() {
        var _this4 = this;

        return this.$getDeviceNavContainer().then(function (deviceNavContainer) {
          return feDialogs.showFor({
            title: WB_LEX.get('bqlQueryBuilder.queryBuilder'),
            type: BqlQueryBuilder,
            value: _this4.$bqlQuery || _this4.getDefaultBqlQuery(),
            formFactor: 'compact',
            properties: {
              hideProjection: true,
              rootNode: deviceNavContainer
            }
          }).then(function (bqlQuery) {
            if (!bqlQuery) {
              return;
            }

            if (bqlQuery) {
              var bqlQueryStr = String(bqlQuery);
              return toSelect(getBqlQuery(bqlQueryStr)).then(function (select) {
                var projection = select.get('projection'),
                    projCol = projection && projection.get('ProjCol'),
                    path = projCol && projCol.get('Path');

                if (String(path).equals('*')) {
                  bqlQueryStr = bqlQueryStr.replace('*', _this4.getBqlProjection());
                }

                return _this4.$doBqlDiscover(bqlQueryStr, _this4.$getPointDeviceExt());
              });
            }
          })["catch"](logSevere);
        });
      }
      /**
       * Get the default BQL Query with a default projection.
       * @returns {baja.Ord}
       */

    }, {
      key: "getDefaultBqlQuery",
      value: function getDefaultBqlQuery() {
        return baja.Ord.make('bql:select ' + this.getBqlProjection() + ' from ' + this.$extentTypeSpec);
      }
      /**
       * Returns the default projection for a point discovery bql query
       * @returns {string}
       */

    }, {
      key: "getBqlProjection",
      value: function getBqlProjection() {
        var columns = COLUMNS.filter(function (column) {
          return column.getName() !== 'icon';
        }).map(function (column) {
          return column.getName();
        });
        columns.push('icon.encodeToString');
        return columns.join(', ');
      }
      /**
       *
       * @returns {{learnModel: (object)}}
       */

    }, {
      key: "saveStateForOrd",
      value: function saveStateForOrd() {
        if (this.$bqlResults) {
          return {
            learnModel: this.$bqlResults
          };
        }
      }
      /**
       *
       * @param state
       * @returns {Promise}
       */

    }, {
      key: "restoreStateForOrd",
      value: function restoreStateForOrd(state) {
        var learnModel = state.learnModel;
        var modelData;

        if (learnModel !== undefined) {
          if (_typeof(learnModel) !== 'object') {
            modelData = JSON.parse(learnModel);
          } else {
            modelData = learnModel;
          }

          this.$bqlResults = modelData;
          var niagaraLearn = new NiagaraPointLearn(this.$bqlQuery, this.$getPointDeviceExt());
          return niagaraLearn.$updateTable(modelData.contents, this.getLearnModel());
        } else {
          this.$bqlResults = undefined;
        }

        return Promise.resolve();
      }
      /**
       * @param state
       * @returns {Promise}
       */

    }, {
      key: "postRestore",
      value: function postRestore(state) {
        var _this5 = this;

        if (!this.$bqlResults) {
          if (this.$bqlQuery && this.$ptDevExtOrd) {
            return baja.Ord.make(this.$ptDevExtOrd).get().then(function (pointDeviceExt) {
              return _this5.$doBqlDiscover(_this5.$bqlQuery, pointDeviceExt);
            })["catch"](logSevere);
          }
        }

        return Promise.resolve();
      }
      /**
       * @private
       * @param {string} bqlQuery 
       * @param {baja.Component} pointDeviceExt 
       * @returns {Promise}
       */

    }, {
      key: "$doBqlDiscover",
      value: function $doBqlDiscover(bqlQuery, pointDeviceExt) {
        var _this6 = this;

        this.$bqlQuery = bqlQuery;
        var niagaraLearn = new NiagaraPointLearn(bqlQuery, pointDeviceExt);
        return niagaraLearn.bqlDiscover({
          learnModel: this.getLearnModel()
        }).then(function (value) {
          _this6.$bqlResults = niagaraLearn.$bqlResults;
          return value;
        });
      }
      /**
       * Returns a baja.NavContainer
       * @private
       * @returns {Promise<baja.NavContainer>} 
       */

    }, {
      key: "$getDeviceNavContainer",
      value: function $getDeviceNavContainer() {
        return this.$getPointDeviceExt().rpc('discoverDeviceRoots').then(function (r) {
          var roots = r.k[0]; // Filter the top level out

          return toNavNode({
            name: roots.n,
            displayName: roots.d,
            ord: roots.o,
            icon: roots.i,
            kids: roots.k
          });
        });
      }
      /**
      * Returns the point ext for the current loaded component. As we may have a folder
      * loaded, this may be several levels up in the component tree.
      *
      * @private
      * @returns {baja.Component}
      */

    }, {
      key: "$getPointDeviceExt",
      value: function $getPointDeviceExt() {
        return compUtils.closest(this.value(), 'niagaraDriver:NiagaraPointDeviceExt');
      }
      /**
       * Get an instance for the given type by loading it from the registry or
       * importing the type if required.
       * @private
       * @param {baja.Component} subject 
       * @returns {Promise.<*>}
       */

    }, {
      key: "$getInstance",
      value: function $getInstance(subject) {
        var typeSpec = subject.get('type');
        return baja.importTypes([typeSpec]).then(function (_ref6) {
          var _ref7 = _slicedToArray(_ref6, 1),
              loadedType = _ref7[0];

          return baja.$(loadedType);
        });
      }
    }]);

    return NiagaraPointUxManager;
  }(PointMgr);
});
