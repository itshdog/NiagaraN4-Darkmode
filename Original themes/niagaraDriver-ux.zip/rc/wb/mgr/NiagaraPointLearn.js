function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

/**
 * @copyright 2021 Tridium, Inc. All Rights Reserved.
 * @author Vikram Nagulan
 */

/**
 * API Status: **Private**
 * @module nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointLearn
 */
define(['baja!', 'nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointLearnNode', 'Promise'], function (baja, NiagaraPointLearnNode, Promise) {
  'use strict';
  /**
   * @class
   * @alias 'module:nmodule/niagaraDriver/rc/wb/mgr/NiagaraPointLearn'
   */

  return /*#__PURE__*/function () {
    /**
     * 
     * @param {string} bqlQuery the discover BQL query string
     * @param {baja.Component} niagaraPointContainer 
     */
    function NiagaraPointLearn(bqlQuery, niagaraPointContainer) {
      _classCallCheck(this, NiagaraPointLearn);

      this.$pointContainer = niagaraPointContainer;
      this.$bqlQuery = bqlQuery;
    }
    /**
     * 
     * @returns {baja.Ord}
     */


    _createClass(NiagaraPointLearn, [{
      key: "getBqlQuery",
      value: function getBqlQuery() {
        return this.$bqlQuery;
      }
      /**
       * @param {object} params 
       * @param {module:nmodule/webEditors/rc/wb/table/tree/TreeTableModel} params.learnModel
       * @returns {Promise}
       */

    }, {
      key: "bqlDiscover",
      value: function bqlDiscover(params) {
        var _this = this;

        var learnModel = params.learnModel;
        return this.$pointContainer.rpc('bqlDiscover', this.$bqlQuery).then(function (result) {
          //Store the results so that they can be accessed later by the manager
          _this.$bqlResults = result;
          return result && _this.$updateTable(result.contents, learnModel);
        });
      }
      /**
       * @private
       * @param {Array.<Object>|Object} data 
       * @param {module:nmodule/webEditors/rc/wb/table/tree/TreeTableModel} learnModel 
       * @returns {Promise}
       */

    }, {
      key: "$updateTable",
      value: function $updateTable(data, learnModel) {
        var _this2 = this;

        if (Array.isArray(data)) {
          return Promise.all(data.map(function (d) {
            return baja.bson.decodeAsync(d);
          })).then(function (values) {
            return values.map(function (value) {
              return _this2.$makeNode(value);
            });
          }).then(function (nodes) {
            return learnModel.clearRows().then(function () {
              return learnModel.insertRows(nodes, 0);
            });
          });
        } else {
          return Promise.resolve();
        }
      }
      /**
       * @private
       * @param {baja.Component} value the interim decoded Component representing one data row
       * @returns {module:nmodule/niagaraDriver/rc/wb/mgr/model/NiagaraPointLearnNode}
       */

    }, {
      key: "$makeNode",
      value: function $makeNode(value) {
        return new NiagaraPointLearnNode(value, this.$pointContainer);
      }
    }]);

    return NiagaraPointLearn;
  }();
});
