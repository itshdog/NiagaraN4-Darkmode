function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/**
 * @copyright 2016 Tridium, Inc. All Rights Reserved.
 * @author Vikram Nagulan
 */

/**
 * API Status: **Private**
 * @module nmodule/bacnet/rc/fe/BacnetObjectIdEditor
 */
define(['baja!', 'jquery', 'nmodule/webEditors/rc/fe/baja/BaseEditor', 'underscore', 'Promise', 'nmodule/webEditors/rc/fe/fe', 'nmodule/bacnet/rc/baja/datatypes/BacnetObjectIdentifier', 'bajaux/events', 'bajaux/Widget', 'baja!bacnet:BacnetObjectType'], function (baja, $, BaseEditor, _, Promise, fe, BacnetObjectIdentifier, events, Widget) {
  'use strict';

  var DESTROY_EVENT = events.DESTROY_EVENT,
      INITIALIZE_EVENT = events.INITIALIZE_EVENT,
      LOAD_EVENT = events.LOAD_EVENT,
      ENABLE_EVENT = events.ENABLE_EVENT,
      DISABLE_EVENT = events.DISABLE_EVENT,
      MODIFY_EVENT = events.MODIFY_EVENT,
      READONLY_EVENT = events.READONLY_EVENT,
      WRITABLE_EVENT = events.WRITABLE_EVENT;
  /**
   * Editor for handling `bacnet:BacnetObjectIdentifier` values.
   *
   * @class
   * @extends module:nmodule/webEditors/rc/fe/baja/BaseEditor
   * @alias module:nmodule/bacnet/rc/fe/BacnetObjectIdEditor
   */

  var BacnetObjectIdEditor = function BacnetObjectIdEditor() {
    BaseEditor.apply(this, arguments);
  };

  BacnetObjectIdEditor.prototype = Object.create(BaseEditor.prototype);
  BacnetObjectIdEditor.prototype.constructor = BacnetObjectIdEditor;
  /**
   * Initialize the bacnet object id editor
   * @param {JQuery} dom
   */

  BacnetObjectIdEditor.prototype.doInitialize = function (dom) {
    var that = this; //Disable events from bubbling up

    dom.on([DESTROY_EVENT, INITIALIZE_EVENT, LOAD_EVENT, ENABLE_EVENT, DISABLE_EVENT, READONLY_EVENT, WRITABLE_EVENT].join(' '), '.editor', false);
    dom.on(MODIFY_EVENT, '.editor', function () {
      that.setModified(true);
      return false;
    });
    return Promise.all([fe.buildFor({
      dom: $('<span class="js-objType" />').appendTo(dom),
      value: baja.DynamicEnum.make({
        range: baja.$('bacnet:BacnetObjectType').getRange()
      }),
      formFactor: 'mini'
    }), fe.buildFor({
      dom: $('<span class="js-instance" />').appendTo(dom),
      value: baja.Integer.DEFAULT,
      formFactor: 'mini'
    })]);
  };
  /**
   * @param {baja.Simple}  boValue `bacnet:BacnetObjectIdentifier` value to load
   */


  BacnetObjectIdEditor.prototype.doLoad = function (boValue) {
    var that = this,
        objType;
    var range = this.properties().getValue('range');

    if (range) {
      objType = baja.DynamicEnum.make({
        ordinal: boValue.getObjectType(),
        range: range
      });
    } else {
      objType = baja.DynamicEnum.make({
        ordinal: boValue.getObjectType(),
        range: baja.$('bacnet:BacnetObjectType').getRange()
      });
    }

    return Promise.all([that.$getSelect().load(objType), that.$getInstanceInput().load(boValue.getInstanceNumber())]);
  };
  /**
   * Read the set values in UI
   * @return {baja.Simple} The read `bacnet:BacnetObjectIdentifier` value
   */


  BacnetObjectIdEditor.prototype.doRead = function () {
    return Promise.all([this.$getSelect().read(), this.$getInstanceInput().read()]).then(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
          objType = _ref2[0],
          objInst = _ref2[1];

      return baja.$("bacnet:BacnetObjectIdentifier", objType.getOrdinal(), objInst);
    });
  };
  /**
   * Make the widgets read only
   *
   * @param {Boolean} readonly
   */


  BacnetObjectIdEditor.prototype.doReadonly = function (readonly) {
    return Promise.all([this.$getSelect().setReadonly(readonly), this.$getInstanceInput().setReadonly(readonly)]);
  };
  /**
   * Make the widgets enabled/disabled
   *
   * @param {Boolean} enabled
   */


  BacnetObjectIdEditor.prototype.doEnabled = function (enabled) {
    return Promise.all([this.$getSelect().setEnabled(enabled), this.$getInstanceInput().setEnabled(enabled)]);
  };
  /**
   * Destroy all the child editors
   * @returns {*}
   */


  BacnetObjectIdEditor.prototype.doDestroy = function () {
    return this.getChildWidgets().destroyAll();
  };
  /**
   * Get the select element.
   *
   * @private
   * @returns {module:bajaux/Widget}
   */


  BacnetObjectIdEditor.prototype.$getSelect = function () {
    return Widget["in"](this.jq().children('.js-objType'));
  };
  /**
   * Get the instance element.
   *
   * @private
   * @returns {module:bajaux/Widget}
   */


  BacnetObjectIdEditor.prototype.$getInstanceInput = function () {
    return Widget["in"](this.jq().children('.js-instance'));
  };

  return BacnetObjectIdEditor;
});
